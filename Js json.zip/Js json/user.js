//<reference path="constants.js" />
/// <reference path="helpers.js" />


const url_params = new URLSearchParams(window.location.search);
const id = url_params.get("id");

const getAlbums = () =>
  getData({
    base_url: base_url,
    path: users_url + "/" + id + "/" + albums_url,
  });

const getTodos = () =>
  getData({
    base_url: base_url,
    path: users_url + "/" + id + "/" + todos_url,
  });
 // href="${user_url + ".html?id=" + id}
const albums_wrapper = document.getElementById("albums");
const todos_wrapper = document.getElementById("todos");

let albumsComponent = ({albums_title, id})=> `
<a href="album/?id=${id}"}>
<div class="p-2 text-primary">
${albums_title}
</div>
</a>
`
let todoComponent = ({iscompleted, todo_title,index}) =>`
<div class="border-dark p-2">
<div>${todo_title}</div>
<div class="form-check">
<input class="form-check-input" type="checkbox" value="" id="FlexCheck-${index}"  ${
    iscompleted ? "checked" : ""
  } >
  <label class="form-check-label" for="flexCheckDefault">
    Default checkbox
  </label>
</div>
 </div>

`
 const getDataParallel = async () => {
  const albums = await getAlbums();
  const todos = await getTodos();
  albums.forEach((albums) => {
    albums_wrapper.innerHTML += albumsComponent({
      albums_title: albums.title, 
      id: albums.id})
  });
  todos.forEach((todo) => {
    todos_wrapper.innerHTML += todoComponent({
        todo_title: todo.title,
         iscompleted: todo.completed,
         index: todo.index,
         
         
        })
  });
 
};
getDataParallel()